../build.linux/nachos -f
../build.linux/nachos -cp num_12000.txt /12000
../build.linux/nachos -cp alphabetic_small.txt /alph_small
../build.linux/nachos -p /12000
echo "========================================="
../build.linux/nachos -l /