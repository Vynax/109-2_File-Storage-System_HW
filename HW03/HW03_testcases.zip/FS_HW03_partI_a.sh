../build.linux/nachos -f
../build.linux/nachos -cp FS_test3 /FS_test3
../build.linux/nachos -e /FS_test3
../build.linux/nachos -p /file3