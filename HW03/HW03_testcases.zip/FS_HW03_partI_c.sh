../build.linux/nachos -f
../build.linux/nachos -cp num_1000000.txt /100_m
echo "========================================="
../build.linux/nachos -l /